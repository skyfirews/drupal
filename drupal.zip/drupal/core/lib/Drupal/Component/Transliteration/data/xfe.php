<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x10 => ',', ',', '.', ':', ';', '!', '?', NULL, NULL, '...', NULL, NULL, NULL, NULL, NULL, NULL,
  0x20 => '', '', '', '~', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x30 => '..', '-', '-', '_', '_', '(', ')', '{', '}', '[', ']', '[(', ')] ', '<<', '>>', '<',
  0x40 => '>', '[', '] ', '{', '}', NULL, NULL, '[', ']', '', '', '', '', '', '', '',
  0x50 => ',', ',', '.', '', ';', ':', '?', '!', '-', '(', ')', '{', '}', '[', ']', '#',
  0x60 => '&', '*', '+', '-', '<', '>', '=', '', '\\', '$', '%', '@', NULL, NULL, NULL, NULL,
  0x70 => '', '', '', NULL, '', NULL, ' a', 'a', ' u', 'u', ' i', 'i', ' ', '', ' ', '',
  0x80 => '', 'a', 'a', 'a', 'a', 'w', 'w', 'a', 'a', 'y', 'y', 'y', 'y', 'a', 'a', 'b',
  0x90 => 'b', 'b', 'b', 't', 't', 't', 't', 't', 't', 'th', 'th', 'th', 'th', 'j', 'j', 'j',
  0xA0 => 'j', 'h', 'h', 'h', 'h', 'kh', 'kh', 'kh', 'kh', 'd', 'd', 'dh', 'dh', 'r', 'r', 'z',
  0xB0 => 'z', 's', 's', 's', 's', 'sh', 'sh', 'sh', 'sh', 's', 's', 's', 's', 'd', 'd', 'd',
  0xC0 => 'd', 't', 't', 't', 't', 'z', 'z', 'z', 'z', '', '', '', '', 'gh', 'gh', 'gh',
  0xD0 => 'gh', 'f', 'f', 'f', 'f', 'q', 'q', 'q', 'q', 'k', 'k', 'k', 'k', 'l', 'l', 'l',
  0xE0 => 'l', 'm', 'm', 'm', 'm', 'n', 'n', 'n', 'n', 'h', 'h', 'h', 'h', 'w', 'w', 'y',
  0xF0 => 'y', 'y', 'y', 'y', 'y', 'la', 'la', 'la', 'la', 'la', 'la', 'la', 'la', NULL, NULL, '',
);
